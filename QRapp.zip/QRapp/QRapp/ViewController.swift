//
//  ViewController.swift
//  QRapp
//
//  Created by abdullah on 07/07/1442 AH.
//

import UIKit
import QRCoder
import Photos
import Toast


class ViewController: UIViewController, UITextFieldDelegate {
    

    @IBOutlet weak var appbar: UIView!
    @IBOutlet weak var appbarTitle: UILabel!
    @IBOutlet weak var TFstring: UITextField!
    @IBOutlet weak var BTNgenerate: UIButton!
    @IBOutlet weak var resultQRcodeImage: UIImageView!
    @IBOutlet weak var LBwarning: UILabel!
    
    @IBOutlet weak var QRcodeBoard: UIView!
    @IBOutlet weak var exportBoard: UIView!
    
    @IBOutlet weak var shareButton: UIButton!
    
    
    
    
    
    @IBOutlet weak var appbarTitleTopMargin: NSLayoutConstraint!
    @IBOutlet weak var appbarMenuButtonTopMargin: NSLayoutConstraint!
    @IBOutlet weak var appbarHeight: NSLayoutConstraint!
    @IBOutlet weak var qrCodeBoardHeight: NSLayoutConstraint!
    @IBOutlet weak var qrCodeBoardWidth: NSLayoutConstraint!
    @IBOutlet weak var menuButtonWidth: NSLayoutConstraint!
    @IBOutlet weak var menuButtonHeight: NSLayoutConstraint!
    @IBOutlet weak var stringTextFieldHeight: NSLayoutConstraint!
    @IBOutlet weak var qrCodeMarginLeft: NSLayoutConstraint!
    @IBOutlet weak var qrCodeMarginBottom: NSLayoutConstraint!
    @IBOutlet weak var qrCodeMarginRight: NSLayoutConstraint!
    @IBOutlet weak var qrCodeMarginTop: NSLayoutConstraint!
    // END
    
    
    private var qrCodeSourceString = ""
    private var qrCodeBackgroundColor = UIColor.white
    private var qrCodeForegroundColor = UIColor.black
    
  //  private var interstitial: GADInterstitial!
    
    // Background Color Picker
    private var selectedColor = UIColor.systemTeal
    private var colorPicker = UIColorPickerViewController()
    
    // Foreground Color Picker
    private var isBgColorSelecting = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resizeView()
        
        colorPicker.delegate = self
        setupBarButton()
        
        setAppbar()
        setStringTextField()
        setResultImage()
        setGenerateButton()
        setBoards()
    
    }
    
    func resizeView(){
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
                case 1136:
                    print("iPhone 5 or 5S or 5C")

                    appbarTitleTopMargin.constant = 35
                    appbarHeight.constant = 190
                    appbarMenuButtonTopMargin.constant = 45
                    qrCodeBoardHeight.constant = 250
                    qrCodeBoardWidth.constant = 250
                    appbarTitle.font = appbarTitle.font.withSize(25)
                    menuButtonWidth.constant = 19
                    menuButtonHeight.constant = 19
                    stringTextFieldHeight.constant = 50
                    TFstring.font = TFstring.font?.withSize(14)
                    qrCodeMarginTop.constant = 80
                    qrCodeMarginBottom.constant = 80
                    qrCodeMarginRight.constant = 80
                    qrCodeMarginLeft.constant = 80
                    
                case 1334:
                    print("iPhone 6/6S/7/8")
                    
                    appbarTitleTopMargin.constant = 40
                    appbarHeight.constant = 215
                    appbarMenuButtonTopMargin.constant = 50

                case 1920, 2208:
                    print("iPhone 6+/6S+/7+/8+")
                case 2436:
                    print("iPhone X/XS/11 Pro")
                case 2688:
                    print("iPhone XS Max/11 Pro Max")
                case 1792:
                    print("iPhone XR/ 11 ")
                default:
                    print("Unknown")
                }
            }
    }
    
    func setAppbar(){
        setRadius(view: appbar, radius: 30)
        setShadow(view: appbar, opacity: 0.9, shadowRadius: 10)
        appbar.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMinXMaxYCorner]
    }
    func setStringTextField(){
        TFstring.delegate = self
        TFstring.backgroundColor = UIColor.white
        setRadius(view: TFstring, radius: 20)
        
        // set padding
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.TFstring.frame.height))
        TFstring.leftView = paddingView
        TFstring.rightView = paddingView
        TFstring.leftViewMode = .always
    }
    func setResultImage(){
        setRadius(view: resultQRcodeImage, radius: 7)
    }
    func setGenerateButton(){
        setRadius(view: BTNgenerate, radius: 25)
        setShadow(view: BTNgenerate, opacity: 0.5, shadowRadius: 10)
    }
    func setBoards(){
        // QRcode Board
        setRadius(view: QRcodeBoard, radius: 15)
        setShadow(view: QRcodeBoard, opacity: 0.2, shadowRadius: 15)
        
        // Option Board
        setRadius(view: exportBoard, radius: 15)
        setShadow(view: exportBoard, opacity: 0.2, shadowRadius: 15)
    
    }
   
    
    
    func setShadow(view: UIView, opacity: Float, shadowRadius: CGFloat){
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowOpacity = opacity
        view.layer.shadowRadius = shadowRadius
    }
    func setRadius(view: UIView, radius: CGFloat){
        view.layer.cornerRadius = radius
    }
    func setStroke(view: UIView, width: CGFloat){
        view.layer.borderWidth = width
        view.layer.borderColor = UIColor.white.cgColor
    }
    
    
    // Generate QRcode
    func generateQRCode(){
       
        
        let sourceString = qrCodeSourceString.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let qrCodeGenerator = QRCodeGenerator()
        qrCodeGenerator.correctionLevel = .H
        
        // set color
        qrCodeGenerator.backgroundColor = qrCodeBackgroundColor
        qrCodeGenerator.foregroundColor = qrCodeForegroundColor
        
        // generate QRcode
        let mQrCode = qrCodeGenerator.createImage(value: sourceString, size: CGSize(width: resultQRcodeImage.bounds.width, height: resultQRcodeImage.bounds.height), encoding: String.Encoding.utf8)
        

        resultQRcodeImage.image = mQrCode
    }
    func showColorPicker(){
        if #available(iOS 14.0, *){
            colorPicker.supportsAlpha = true
            
            colorPicker.selectedColor = selectedColor
            present(colorPicker, animated: true)
        }else{
            self.view.makeToast("Color pallete is supported only on iOS 14.0 and later.")
        }
        
    }
    func setupBarButton(){
        _ = UIAction(title: "Pick Color"){ _ in
            self.showColorPicker()
        }
    }
    
    // Export Action
    func saveQrCode(){
        // request Album Permission
        if PHPhotoLibrary.authorizationStatus() != .authorized{
            PHPhotoLibrary.requestAuthorization { (status) in
               // system permission request dialog
                if status == .authorized{
                    return
                }
            }
            
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Access album permission", message: "To save QrCode, you need to allow permission for access album.", preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .default) { (action) in
                    // Open permission setting
                    guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                                return
                            }

                            if UIApplication.shared.canOpenURL(settingsUrl) {
                                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                                    print("Settings opened: \(success)") // Prints true
                                })
                            }
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                    print("cancel button clicked")
                }
                alert.addAction(cancelAction)
                alert.addAction(defaultAction)
                self.present(alert, animated: true, completion: nil)
            }
        }else{
            // Save Alert
            DispatchQueue.main.async {
                let dialog = UIAlertController(title: "Save", message: "Save the QrCode to the album?", preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .default) { (action) in
                    if let qrCode = self.captureQrCode(){
                        UIImageWriteToSavedPhotosAlbum(qrCode, nil, nil, nil)
                    }else{
                        self.view.makeToast("Please try again")
                    }
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                    // cancel Action
                }
                dialog.addAction(cancelAction)
                dialog.addAction(defaultAction)
                self.present(dialog, animated: true, completion: nil)
            }
        }
    }
    func shareQrCode(){
        if let qrCode = captureQrCode(){
            let imageToShare = [qrCode]
            let activityVC = UIActivityViewController(activityItems: imageToShare as [Any], applicationActivities: nil)
     
            if (UIDevice.current.userInterfaceIdiom == .pad) {
                // if device is ipad
                
                activityVC.popoverPresentationController?.sourceView = shareButton!
                activityVC.popoverPresentationController?.sourceRect = (shareButton as AnyObject).bounds
            }
            
            self.present(activityVC, animated: true, completion: nil)
        }else{
            self.view.makeToast("Please try again")
        }
    }
    
    
    func captureQrCode() -> UIImage?{
        UIGraphicsBeginImageContextWithOptions(QRcodeBoard.frame.size, false, 0.0)
        QRcodeBoard.layer.render(in: UIGraphicsGetCurrentContext()!)
        let qrCode = UIGraphicsGetImageFromCurrentImageContext()
        
        return qrCode!
    }

    
    
    // Generate Button Action
    @IBAction func generateQRcodeAction(_ sender: Any) {
        qrCodeSourceString = TFstring.text ?? ""
        generateQRCode()
       // showAdMob()
    }
    
    // Export Actions
    @IBAction func saveButtonAction(_ sender: Any) {
        saveQrCode()
    }
    @IBAction func shareButtonAction(_ sender: Any) {
        shareQrCode()
    }
    


    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
}


extension ViewController: UIColorPickerViewControllerDelegate{
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        selectedColor = viewController.selectedColor
        
        print("color changed")
        if isBgColorSelecting {
            QRcodeBoard.backgroundColor = selectedColor
            qrCodeBackgroundColor = selectedColor
        }else{
            qrCodeForegroundColor = selectedColor
        }
        generateQRCode()
        
    }
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        print("did dismiss function")
    }
}
